#!/usr/bin/env python3
import subprocess
import sys
import os
import signal
import time
import socket
import requests
import json
import threading
from datetime import datetime
from urllib.parse import urlparse

# ============ CONFIGURAÇÕES ============
# COLOQUE AQUI SEU TOKEN DO BOT E SEU CHAT ID
BOT_TOKEN = "8858026333:AAHc5SzjaRTCA6CaOjkHJ_Mvr1yYuSMVRKI"  # Ex: "123456789:ABCdefGHIjklMNOpqrsTUVwxyz"
CHAT_ID = "8130788079"  # Ex: "123456789"

# Configurações dos serviços
SERVIDORES = [
    {"nome": "Site Principal", "url": "http://localhost:8081", "porta": 8081},
    {"nome": "Site Michel", "url": "http://localhost:8082", "porta": 8082}
]

# Intervalo de verificação (segundos)
INTERVALO_VERIFICACAO = 30  # Verifica a cada 30 segundos
# =======================================

processos = []
nomes_processos = []
ultimo_alerta = {}
bot_ativo = False
verificacao_ativa = True

class TelegramBot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.ultimo_update_id = 0
        
    def enviar_mensagem(self, texto, parse_mode="HTML"):
        """Envia mensagem para o Telegram"""
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": texto,
                "parse_mode": parse_mode
            }
            response = requests.post(url, json=payload, timeout=10)
            return response.json()
        except Exception as e:
            print(f"❌ Erro ao enviar mensagem: {e}")
            return None
    
    def get_updates(self):
        """Busca novas mensagens do bot"""
        try:
            url = f"{self.base_url}/getUpdates"
            params = {
                "offset": self.ultimo_update_id + 1,
                "timeout": 30
            }
            response = requests.get(url, params=params, timeout=35)
            data = response.json()
            
            if data.get("ok") and data.get("result"):
                for update in data["result"]:
                    self.ultimo_update_id = update["update_id"]
                    if "message" in update and "text" in update["message"]:
                        return update["message"]
            return None
        except Exception as e:
            return None
    
    def processar_comandos(self, message):
        """Processa comandos recebidos"""
        if not message:
            return
        
        chat_id = message["chat"]["id"]
        texto = message.get("text", "")
        user = message["from"]["first_name"]
        
        # Só responde se for o chat autorizado
        if str(chat_id) != str(self.chat_id):
            self.enviar_mensagem_para(chat_id, "⛔ Acesso não autorizado!")
            return
        
        if texto.startswith("/ping"):
            self.comando_ping()
        
        elif texto.startswith("/status"):
            self.comando_status()
        
        elif texto.startswith("/servicos"):
            self.comando_listar_servicos()
        
        elif texto.startswith("/log"):
            self.comando_log()
        
        elif texto.startswith("/ajuda") or texto.startswith("/help"):
            self.comando_ajuda()
        
        elif texto.startswith("/speed"):
            self.comando_speedtest()
        
        elif texto.startswith("/reiniciar"):
            args = texto.split()
            if len(args) > 1:
                self.comando_reiniciar_servico(args[1])
            else:
                self.enviar_mensagem("❌ Use: /reiniciar <nome_do_serviço>")
    
    def enviar_mensagem_para(self, chat_id, texto):
        """Envia mensagem para um chat específico"""
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": texto,
                "parse_mode": "HTML"
            }
            requests.post(url, json=payload, timeout=10)
        except:
            pass
    
    def comando_ping(self):
        """Comando /ping - Verifica velocidade dos sites"""
        mensagem = "🏓 <b>VERIFICAÇÃO DE VELOCIDADE</b>\n\n"
        
        for servidor in SERVIDORES:
            nome = servidor["nome"]
            url = servidor["url"]
            porta = servidor["porta"]
            
            inicio = time.time()
            try:
                response = requests.get(url, timeout=5)
                tempo = (time.time() - inicio) * 1000
                
                if response.status_code == 200:
                    tamanho = len(response.content)
                    mensagem += f"✅ <b>{nome}</b>\n"
                    mensagem += f"   ⚡ Resposta: {tempo:.0f}ms\n"
                    mensagem += f"   📦 Tamanho: {tamanho} bytes\n"
                    mensagem += f"   🔗 URL: {url}\n\n"
                else:
                    mensagem += f"⚠️ <b>{nome}</b>\n"
                    mensagem += f"   Status HTTP: {response.status_code}\n\n"
            except requests.exceptions.Timeout:
                mensagem += f"❌ <b>{nome}</b>\n"
                mensagem += f"   ⏰ Timeout (5s) - Servidor não respondeu\n"
                mensagem += f"   🔌 Porta {porta} pode estar fechada\n\n"
            except requests.exceptions.ConnectionError:
                mensagem += f"❌ <b>{nome}</b>\n"
                mensagem += f"   🔌 Conexão recusada - Servidor offline\n"
                mensagem += f"   🚫 Porta {porta} não está ouvindo\n\n"
            except Exception as e:
                mensagem += f"❌ <b>{nome}</b>\n"
                mensagem += f"   Erro: {str(e)[:100]}\n\n"
        
        # Verifica internet geral
        try:
            inicio = time.time()
            response = requests.get("https://www.google.com", timeout=5)
            tempo_internet = (time.time() - inicio) * 1000
            mensagem += f"🌐 <b>Internet Geral</b>\n"
            mensagem += f"   ⚡ Google: {tempo_internet:.0f}ms\n"
            mensagem += f"   📡 Conectividade: OK"
        except:
            mensagem += f"🌐 <b>Internet Geral</b>\n"
            mensagem += f"   ❌ SEM CONEXÃO COM INTERNET!"
        
        self.enviar_mensagem(mensagem)
    
    def comando_status(self):
        """Comando /status - Status detalhado"""
        mensagem = "📊 <b>STATUS DO SISTEMA</b>\n\n"
        mensagem += f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n"
        
        # Status dos serviços
        for servidor in SERVIDORES:
            nome = servidor["nome"]
            url = servidor["url"]
            
            try:
                response = requests.get(url, timeout=5)
                if response.status_code == 200:
                    mensagem += f"✅ {nome}: ONLINE\n"
                else:
                    mensagem += f"⚠️ {nome}: Status {response.status_code}\n"
            except:
                mensagem += f"❌ {nome}: OFFLINE\n"
        
        # Status do Cloudflare
        cloudflare_status = verificar_cloudflare()
        mensagem += f"\n{'✅' if cloudflare_status else '❌'} Cloudflare Tunnel: "
        mensagem += f"{'ATIVO' if cloudflare_status else 'INATIVO'}\n"
        
        # Status do WakeLock
        mensagem += f"✅ WakeLock: ATIVO\n"
        
        # Verifica processos
        processos_ativos = sum(1 for p in processos if p.poll() is None)
        mensagem += f"\n📈 Processos ativos: {processos_ativos}/{len(processos)}"
        
        self.enviar_mensagem(mensagem)
    
    def comando_listar_servicos(self):
        """Comando /servicos - Lista serviços"""
        mensagem = "🔧 <b>SERVIÇOS CONFIGURADOS</b>\n\n"
        
        for i, servidor in enumerate(SERVIDORES, 1):
            mensagem += f"{i}. <b>{servidor['nome']}</b>\n"
            mensagem += f"   📍 URL: {servidor['url']}\n"
            mensagem += f"   🔌 Porta: {servidor['porta']}\n\n"
        
        mensagem += "💡 Use /ping para testar velocidade\n"
        mensagem += "💡 Use /status para verificar status"
        
        self.enviar_mensagem(mensagem)
    
    def comando_log(self):
        """Comando /log - Últimos alertas"""
        if not ultimo_alerta:
            self.enviar_mensagem("📋 Nenhum alerta registrado ainda!")
            return
        
        mensagem = "📋 <b>ÚLTIMOS ALERTAS</b>\n\n"
        for servico, info in ultimo_alerta.items():
            status_emoji = "✅" if info["status"] == "online" else "❌"
            mensagem += f"{status_emoji} <b>{servico}</b>\n"
            mensagem += f"   Status: {info['status']}\n"
            mensagem += f"   Última mudança: {info['timestamp']}\n\n"
        
        self.enviar_mensagem(mensagem)
    
    def comando_ajuda(self):
        """Comando /ajuda - Lista comandos"""
        mensagem = """🤖 <b>COMANDOS DISPONÍVEIS</b>

/ping - Testar velocidade dos sites
/status - Status completo do sistema
/servicos - Listar serviços configurados
/log - Últimos alertas do sistema
/speed - Testar velocidade da internet
/ajuda - Mostrar esta mensagem

🚨 <b>Alertas automáticos:</b>
• Serviços offline/online
• Quedas de internet
• Falhas no Cloudflare
• Erros críticos do sistema"""
        
        self.enviar_mensagem(mensagem)
    
    def comando_speedtest(self):
        """Comando /speed - Teste de velocidade simples"""
        self.enviar_mensagem("⏳ Iniciando teste de velocidade... (pode levar 30s)")
        
        mensagem = "🚀 <b>TESTE DE VELOCIDADE</b>\n\n"
        
        # Teste de download
        try:
            inicio = time.time()
            response = requests.get("https://speed.cloudflare.com/__down?bytes=5000000", timeout=30)
            tempo = time.time() - inicio
            tamanho_mb = len(response.content) / (1024 * 1024)
            velocidade = tamanho_mb / tempo
            mensagem += f"📥 <b>Download:</b> {velocidade:.1f} MB/s\n"
        except:
            mensagem += f"📥 <b>Download:</b> ❌ Falhou\n"
        
        # Teste de latência
        try:
            latencias = []
            for _ in range(3):
                inicio = time.time()
                requests.get("https://www.google.com", timeout=5)
                latencias.append((time.time() - inicio) * 1000)
            
            latencia_media = sum(latencias) / len(latencias)
            mensagem += f"📡 <b>Latência:</b> {latencia_media:.0f}ms\n"
            mensagem += f"📊 <b>Min/Max:</b> {min(latencias):.0f}/{max(latencias):.0f}ms"
        except:
            mensagem += f"📡 <b>Latência:</b> ❌ Falhou"
        
        self.enviar_mensagem(mensagem)
    
    def comando_reiniciar_servico(self, nome_servico):
        """Comando /reiniciar - Reinicia um serviço específico"""
        self.enviar_mensagem(f"⏳ Reiniciando {nome_servico}...")
        # Aqui você pode adicionar lógica para reiniciar serviços específicos
        time.sleep(2)
        self.comando_status()

def verificar_cloudflare():
    """Verifica se o túnel Cloudflare está rodando"""
    try:
        result = subprocess.run(
            ["pgrep", "-f", "cloudflared"],
            capture_output=True,
            text=True
        )
        return bool(result.stdout.strip())
    except:
        return False

def monitorar_servicos(bot):
    """Thread de monitoramento contínuo"""
    global ultimo_alerta, verificacao_ativa
    
    print("\n👀 Monitoramento iniciado! Verificando a cada", INTERVALO_VERIFICACAO, "segundos...")
    print("=" * 50)
    
    # Estado inicial
    estados_anteriores = {}
    for servidor in SERVIDORES:
        estados_anteriores[servidor["nome"]] = None
    cloudflare_anterior = None
    
    # Envia mensagem de inicialização
    if bot:
        bot.enviar_mensagem(
            "🟢 <b>SISTEMA INICIADO</b>\n\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
            "📡 Monitoramento ativo\n"
            "🔔 Alertas configurados"
        )
    
    while verificacao_ativa:
        try:
            # Verifica cada servidor
            for servidor in SERVIDORES:
                nome = servidor["nome"]
                url = servidor["url"]
                
                try:
                    response = requests.get(url, timeout=5)
                    status_atual = "online" if response.status_code == 200 else "problema"
                except:
                    status_atual = "offline"
                
                # Se mudou o estado
                if estados_anteriores[nome] != status_atual:
                    estados_anteriores[nome] = status_atual
                    
                    if status_atual == "online":
                        mensagem = f"✅ <b>{nome} VOLTOU!</b>\n🕐 {datetime.now().strftime('%H:%M:%S')}\n🔗 {url}"
                    elif status_atual == "offline":
                        mensagem = f"🚨 <b>{nome} CAIU!</b>\n🕐 {datetime.now().strftime('%H:%M:%S')}\n🔗 {url}\n❌ Servidor não responde"
                    else:
                        mensagem = f"⚠️ <b>{nome} COM PROBLEMA</b>\n🕐 {datetime.now().strftime('%H:%M:%S')}\n🔗 {url}"
                    
                    ultimo_alerta[nome] = {
                        "status": status_atual,
                        "timestamp": datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    }
                    
                    print(f"{'✅' if status_atual == 'online' else '❌'} Alerta: {nome} - {status_atual}")
                    
                    if bot:
                        bot.enviar_mensagem(mensagem)
            
            # Verifica Cloudflare
            cf_status = verificar_cloudflare()
            if cloudflare_anterior != cf_status:
                cloudflare_anterior = cf_status
                
                if cf_status:
                    mensagem = "✅ <b>Cloudflare Tunnel RECONECTADO!</b>"
                else:
                    mensagem = "🚨 <b>Cloudflare Tunnel CAIU!</b>\n⚠️ Sites externos inacessíveis"
                
                if bot:
                    bot.enviar_mensagem(mensagem)
                print(mensagem)
            
            # Verifica internet geral a cada 5 verificações
            if int(time.time()) % (INTERVALO_VERIFICACAO * 5) < INTERVALO_VERIFICACAO:
                try:
                    requests.get("https://www.google.com", timeout=5)
                except:
                    if bot:
                        bot.enviar_mensagem(
                            "🌐 <b>ALERTA DE INTERNET</b>\n"
                            "❌ Sem conexão com a internet!\n"
                            f"🕐 {datetime.now().strftime('%H:%M:%S')}"
                        )
        
        except Exception as e:
            print(f"Erro no monitoramento: {e}")
        
        time.sleep(INTERVALO_VERIFICACAO)

def iniciar_termux_wakelock():
    """Mantém o Termux ativo em background"""
    try:
        subprocess.run(
            ["termux-wake-lock"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False
        )
        print("✓ termux-wake-lock ativado")
        return True
    except Exception as e:
        print(f"✗ Erro no termux-wake-lock: {e}")
        return False

def iniciar_cloudflared():
    """Inicia o túnel Cloudflare"""
    try:
        proc = subprocess.Popen(
            ["cloudflared", "tunnel", "run", "meutunel"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        processos.append(proc)
        nomes_processos.append("Cloudflare Tunnel")
        print("✓ Cloudflared tunnel iniciado")
        return True
    except Exception as e:
        print(f"✗ Erro no cloudflared: {e}")
        return False

def iniciar_site_principal():
    """Inicia servidor PHP para o site principal"""
    try:
        if not os.path.exists("/sdcard/download/painel"):
            print(f"✗ Diretório /sdcard/download/painel não encontrado!")
            return False
        
        os.chdir("/sdcard/download/painel")
        proc = subprocess.Popen(
            ["php", "-S", "localhost:8081"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        processos.append(proc)
        nomes_processos.append("Site Principal (8081)")
        print("✓ Site principal iniciado em localhost:8081")
        return True
    except Exception as e:
        print(f"✗ Erro no site principal: {e}")
        return False

def iniciar_site_michel():
    """Inicia servidor PHP para o site do Michel"""
    try:
        if not os.path.exists("/sdcard/download/public"):
            print(f"✗ Diretório /sdcard/download/public não encontrado!")
            return False
        
        os.chdir("/sdcard/download/public")
        proc = subprocess.Popen(
            ["php", "-S", "localhost:8082"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        processos.append(proc)
        nomes_processos.append("Site Michel (8082)")
        print("✓ Site do Michel iniciado em localhost:8082")
        return True
    except Exception as e:
        print(f"✗ Erro no site do Michel: {e}")
        return False

def limpar_processos(signum=None, frame=None):
    """Finaliza todos os processos ao encerrar o script"""
    global verificacao_ativa, bot_ativo
    
    print("\n🛑 Encerrando todos os serviços...")
    verificacao_ativa = False
    
    # Para o monitoramento
    time.sleep(1)
    
    # Envia mensagem de desligamento
    if bot_ativo and BOT_TOKEN != "SEU_TOKEN_AQUI":
        bot_temp = TelegramBot(BOT_TOKEN, CHAT_ID)
        bot_temp.enviar_mensagem(
            "🔴 <b>SISTEMA DESLIGADO</b>\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n"
            "👋 Até mais!"
        )
    
    for i, proc in enumerate(processos):
        try:
            nome = nomes_processos[i]
            proc.terminate()
            proc.wait(timeout=3)
            print(f"  ✓ {nome} encerrado")
        except:
            try:
                proc.kill()
            except:
                pass
    
    try:
        subprocess.run(["termux-wake-unlock"], 
                      stdout=subprocess.DEVNULL, 
                      stderr=subprocess.DEVNULL,
                      check=False)
        print("✓ Wakelock liberado")
    except:
        pass
    
    print("✅ Todos os serviços foram encerrados")
    sys.exit(0)

def main():
    global bot_ativo
    
    print("=" * 60)
    print("🚀 INICIANDO SISTEMA COMPLETO COM MONITORAMENTO")
    print("=" * 60)
    print()
    
    # Verifica configurações do bot
    if BOT_TOKEN == "SEU_TOKEN_AQUI" or CHAT_ID == "SEU_CHAT_ID_AQUI":
        print("⚠️  AVISO: Configure o TOKEN e CHAT_ID do Telegram!")
        print("   Edite o script e adicione suas credenciais")
        print()
    
    # Registra handlers
    signal.signal(signal.SIGINT, limpar_processos)
    signal.signal(signal.SIGTERM, limpar_processos)
    
    # Inicia serviços
    print("📡 Iniciando serviços...")
    print("-" * 50)
    
    wakelock_ok = iniciar_termux_wakelock()
    time.sleep(0.3)
    
    cloudflare_ok = iniciar_cloudflared()
    time.sleep(0.5)
    
    site1_ok = iniciar_site_principal()
    time.sleep(0.3)
    
    site2_ok = iniciar_site_michel()
    
    print("-" * 50)
    print()
    
    # Inicia bot Telegram
    bot = None
    if BOT_TOKEN != "SEU_TOKEN_AQUI" and CHAT_ID != "SEU_CHAT_ID_AQUI":
        bot = TelegramBot(BOT_TOKEN, CHAT_ID)
        bot_ativo = True
        print("🤖 Bot Telegram conectado!")
        
        # Thread para receber comandos
        def receber_comandos():
            while verificacao_ativa:
                message = bot.get_updates()
                if message:
                    bot.processar_comandos(message)
                time.sleep(1)
        
        thread_comandos = threading.Thread(target=receber_comandos, daemon=True)
        thread_comandos.start()
    else:
        print("⚠️  Bot Telegram não configurado - monitoramento sem alertas")
    
    # Thread de monitoramento
    thread_monitor = threading.Thread(
        target=monitorar_servicos, 
        args=(bot,), 
        daemon=True
    )
    thread_monitor.start()
    
    # Status final
    print("\n" + "=" * 60)
    print("✅ SISTEMA INICIADO COM SUCESSO!")
    print("=" * 60)
    print(f"  Wake Lock: {'✅' if wakelock_ok else '❌'}")
    print(f"  Cloudflare: {'✅' if cloudflare_ok else '❌'}")
    print(f"  Site Principal: {'✅ http://localhost:8081' if site1_ok else '❌'}")
    print(f"  Site Michel: {'✅ http://localhost:8082' if site2_ok else '❌'}")
    print(f"  Bot Telegram: {'✅ Conectado' if bot_ativo else '❌ Não configurado'}")
    print(f"  Monitoramento: ✅ Ativo (a cada {INTERVALO_VERIFICACAO}s)")
    print()
    print("💡 Comandos do bot: /ping, /status, /servicos, /log, /speed")
    print("⚠️  Pressione Ctrl+C para encerrar tudo")
    print("=" * 60)
    
    # Mantém o script rodando
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()